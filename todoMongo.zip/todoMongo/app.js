const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const serverURL = "";

const app = express();
const port = 8000;

app.set("view engine", "ejs");
app.use(express.urlencoded({extended:true}));
app.use(express.static('public'));

//DATABASE CONNECTION
mongoose.connect(serverURL, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("DB CONNECTED");
}).catch(error => {
    console.error("Error connecting to MongoDB:", error);
});

const trySchema = new mongoose.Schema({
    name: String
})

const item = mongoose.model("task", trySchema);

const todo = new item({
    name: ""
})

app.get("/", async (req,res) =>{
    try{
        const found = await item.find();
        res.render("list", {ejes: found})
    }catch(error){
        console.log("ERROR FINDING ITEMS")
    }
})

app.post("/", (req, res) =>{
    const itemName = req.body.ele1;
    const todoNew = new item({
        name: itemName
    });
    try{
        todoNew.save();
        res.redirect("/");
    }catch(err){
        console.log("Cannot save")
    }
})


app.post("/delete", async (req,res) =>{
    const checked = req.body.check1;
    try{
        const deleted = await item.findByIdAndRemove(checked);
        res.redirect("/");
    }catch(err){
        console.log("Could nOt dlete")
    }

})



app.listen(port, () =>{
    console.log("Server Running .....")
})


